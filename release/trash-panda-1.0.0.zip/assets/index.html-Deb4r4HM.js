import{T as i,D as g}from"./default-racoon-colour-C6zlquoW.js";(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))c(e);new MutationObserver(e=>{for(const t of e)if(t.type==="childList")for(const s of t.addedNodes)s.tagName==="LINK"&&s.rel==="modulepreload"&&c(s)}).observe(document,{childList:!0,subtree:!0});function r(e){const t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?t.credentials="include":e.crossOrigin==="anonymous"?t.credentials="omit":t.credentials="same-origin",t}function c(e){if(e.ep)return;e.ep=!0;const t=r(e);fetch(e.href,t)}})();const d=()=>!!(window.matchMedia("(prefers-color-scheme: dark)").matches||window.matchMedia("(prefers-color-scheme: no-preference)").matches),a=-100,l=50,L="rgb(0,0,255)",h="rgb(0,255,0)",O="rgb(255,0,0)",b=(n,o)=>{const[r,c,e]=o.toLowerCase().replace("rgb(","").replaceAll(")","").split(",").map(m=>Number(m)),t=`rgb(${r+a},${c+a+30},${e+a-30})`,s=`rgb(${r+l+30},${c+l+0},${e+l+30})`,f=`rgb(${r},${c},${e})`,u=n.replaceAll(L,f).replaceAll(h,s).replaceAll(O,t);return console.log({svgString:n,resultString:u}),u},p=async n=>{const o=document.getElementById("app");o&&(o.innerHTML="");const r=document.createElement("div");r.className="popup-page",r.style.backgroundColor=d()?i.DARK.BACKGROUND:i.LIGHT.BACKGROUND;const e=await(await fetch(chrome.runtime.getURL("cooper-coffee.svg"))).text(),t=b(e,n),s=encodeURIComponent(t);r.innerHTML=`
    <div class='popup-container'>
      <p style='color:${d()?i.DARK.TEXT:i.LIGHT.TEXT};font-size: 0.75rem;'>
        Thanks for using Trash Panda!
        Please go to Github to leave a star or request new features
      </p>
      <button class='button'>Github</button>
    </div>
    <div>
      <img class="cooper" src="${`data:image/svg+xml,${s}`}">
    </div>
  `,document.body.appendChild(r)};document.addEventListener("DOMContentLoaded",()=>{chrome.tabs.query({active:!0,currentWindow:!0},n=>{const o=n[0];o&&o.id&&chrome.tabs.sendMessage(o.id,{type:"GET_COLOR"},r=>{if(chrome.runtime.lastError){p(g);return}r&&r.color&&(console.log("Popup received color:",r.color),p(r.color))})})});
