const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/editor.main-ITkLqA0n.js","assets/monaco-editor.css"])))=>i.map(i=>d[i]);
const U=t=>t.endsWith(".js"),v={DARK:{BACKGROUND:"#24051eff"},LIGHT:{BACKGROUND:"#d46ec0ff"}},M=()=>{for(document.querySelectorAll('style, link[rel="stylesheet"]').forEach(t=>t.remove());document.body.firstChild;)document.body.removeChild(document.body.firstChild);document.documentElement.removeAttribute("style"),document.body.removeAttribute("style"),document.body.style.background=v.LIGHT.BACKGROUND},_=["Who’s fault was it?","Blame someone, anyone.","Oops. Not again.","I test in prod","Another day, another disaster.","Someone’s in trouble.","I’ve seen worse… maybe.","Who wrote this.","I wonder if McDonalds is hiring.","What does grass feel like.","Someone check the stock market.","Who let this function exist?","Callbacks are a war crime.","I’m a JS dev, send help.","My life is just callbacks and regrets.","My brain is a garbage collected heap.","The only constant is undefined.","undefined is my spirit animal.","My stack trace knows more about me than I do.","The only thing constant is my regret.","Who even invented modules?","I’m the main character in someone else’s bug report.","Another day, another Stack Overflow spiral.","I’m 80% caffeine, 20% regret.","Somehow I get paid for this.","Every deployment is a personal gamble.","There’s always one more framework.","Does anyone else feel like this or am I cursed.","They told me I’d ship features, not despair.","Is this what adulthood feels like?","Mamma mia, time for some spaghetti.","Sometimes I wonder if I’m the bug.","Is it too late to quit?","My mental stack overflows daily.","I ship despair in 2KB chunks.","Every bug is a personal insult.","I consider burning my laptop ritualistically.","My brain just threw a runtime error.","Whats vitamin D?","Yep, this definitely looks maintainable.","Ah yes, so this is what clean code looks like.","Oh look, another utils.js with 5,000 lines, beautiful.","Yep, everything is “modular,” except when it isn’t.","So much for single responsibility, this file is responsible for my breakdown.","This techdebt has techdebt.","Whoever wrote this should be on a watchlist.","Is spaghetti an official design pattern now?","This code smells like unpaid internships.","Clean coding principles? More like Stockholm syndrome principles.","I’ve seen ransom notes more readable than this.","This promise chain looks like a cry for help.","I should rename this file footgun.js.","Let's rewrite this in Rust."],O=()=>{const t=document.createElement("div");t.className="splash-page",t.innerHTML=`
    <img class="splash-logo" src="${chrome.runtime.getURL("trash-logo.svg")}">
    <h2 class="splash-loading-text">Loading</h2>
    <br><br><br><br>
    <div class="bubble">
      ${_.sort(()=>Math.random()-.5)[0]}
    </div>
    <img class="cooper" src="${chrome.runtime.getURL("cooper.png")}">
    <br>
  `,document.body.appendChild(t)},A="modulepreload",D=function(t){return"/"+t},S={},b=function(e,o,n){let r=Promise.resolve();if(o&&o.length>0){let i=function(a){return Promise.all(a.map(u=>Promise.resolve(u).then(m=>({status:"fulfilled",value:m}),m=>({status:"rejected",reason:m}))))};document.getElementsByTagName("link");const c=document.querySelector("meta[property=csp-nonce]"),h=c?.nonce||c?.getAttribute("nonce");r=i(o.map(a=>{if(a=D(a),a in S)return;S[a]=!0;const u=a.endsWith(".css"),m=u?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${a}"]${m}`))return;const l=document.createElement("link");if(l.rel=u?"stylesheet":A,u||(l.as="script"),l.crossOrigin="",l.href=a,h&&l.setAttribute("nonce",h),document.head.appendChild(l),u)return new Promise((L,y)=>{l.addEventListener("load",L),l.addEventListener("error",()=>y(new Error(`Unable to preload CSS for ${a}`)))})}))}function s(i){const c=new Event("vite:preloadError",{cancelable:!0});if(c.payload=i,window.dispatchEvent(c),!c.defaultPrevented)throw i}return r.then(i=>{for(const c of i||[])c.status==="rejected"&&s(c.reason);return e().catch(s)})},k=()=>!!(window.matchMedia("(prefers-color-scheme: dark)").matches||window.matchMedia("(prefers-color-scheme: no-preference)").matches),R=({type:t,title:e,message:o})=>{const n=document.createElement("div");n.className="dialog-overlay";const r=document.createElement("div");r.className=`dialog ${t}`,r.innerHTML=`
    <h1>${e}</h1>
    <p>${o}</p>
    
    <button class="dialog-close button">Close</button>
  `,n.appendChild(r),document.body.appendChild(n);const s=()=>n.remove();n.addEventListener("click",i=>{i.target===n&&s()}),r.querySelector(".dialog-close")?.addEventListener("click",s)},N=()=>{const t=document.querySelector(".splash-page");t&&t.remove()},x=t=>{const e=`importScripts("${t}");`,o=new Blob([e],{type:"application/javascript"}),n=URL.createObjectURL(o);return new Worker(n,{type:"classic"})},j=()=>{self.MonacoEnvironment={getWorker(t,e){return e==="typescript"||e==="javascript"?x(chrome.runtime.getURL("assets/monaco-workers/ts.worker.bundle.js")):e==="html"?x(chrome.runtime.getURL("assets/monaco-workers/html.worker.bundle.js")):e==="editorWorkerService"?x(chrome.runtime.getURL("assets/monaco-workers/editor.worker.bundle.js")):()=>({terminate(){},postMessage(){},addEventListener(){},removeEventListener(){},dispatchEvent(){return!1}})}}},$=(t,e,o)=>{const n=t.split(`
`);let r=0;for(let s=0;s<e-1;s++)r+=n[s].length+1;return r+(o-1)},W=()=>{const t=document.createElement("div");t.className="status-wrapper";const e=document.createElement("img");e.id="cooper",e.src=chrome.runtime.getURL("cooper.png"),e.alt="trash icon";const o=document.createElement("footer");o.className="status-bar",t.appendChild(e),t.appendChild(o),document.body.appendChild(t)},P=async({code:t,cursorOffset:e})=>{const{formatWithCursor:o}=await b(async()=>{const{formatWithCursor:i}=await import("./standalone-C-enP7Mo.js");return{formatWithCursor:i}},[]),n=(await b(async()=>{const{default:i}=await import("./estree-BKUavBKs.js");return{default:i}},[])).default,r=await b(()=>import("./babel-nAzM5Yej.js"),[]);return await o(t,{cursorOffset:e,parser:"babel",plugins:[r,n]})},B=t=>t.split(/\r?\n/).map(e=>e.length),z=async({sourceCode:t,enableCursor:e,initialColNumber:o,initialLineNumber:n})=>{const r=await b(()=>import("./editor.main-ITkLqA0n.js").then(g=>g.e),__vite__mapDeps([0,1])),{Range:s,editor:i,Selection:c}=r,h=t,a=B(h),u=Math.max(...a),m=a.length;let l=!0;n>m&&(R({type:"warn",title:"Out of range",message:`Line number ${n} is beyond the total line count`}),l=!1),a[n-1]<o&&(R({type:"warn",title:"Out of range",message:`Line ${n} has a max character count of ${a[n-1]}, you provided ${o}`}),l=!1);const y=l?$(h,n,o):1,E=await P({code:h,cursorOffset:y}),C=document.createElement("div");C.id="editor",document.body.appendChild(C);const w=document.getElementById("editor");w.style.height="calc(100vh - 20px)",w.style.width="100vw",j(),console.log(k());const p=i.create(w,{readOnly:!0,glyphMargin:!0,automaticLayout:!0,language:"javascript",value:E.formatted,theme:k()?"vs-dark":"vs",maxTokenizationLineLength:u});if(W(),p.onMouseDown(g=>{g.target.type===r.editor.MouseTargetType.CONTENT_TEXT&&p.trigger("","editor.action.revealDefinition",{})}),l&&e){const d=p.getModel().getPositionAt(E.cursorOffset);p.createDecorationsCollection([{range:new s(d.lineNumber,d.column,d.lineNumber,d.column),options:{beforeContentClassName:"my-inline-tooltip",hoverMessage:{value:`⚠️ Stack trace location ${n}:${o} ⚠️`}}}]),p.revealPositionInCenter(d);const T=p.getModel().getLineLength(d.lineNumber);p.setSelection(new c(d.lineNumber,1,d.lineNumber,T+1)),p.createDecorationsCollection([{range:new s(d.lineNumber,1,d.lineNumber,1),options:{isWholeLine:!0,className:"error-line-highlight",glyphMarginClassName:"error-gutter-icon"}}])}setTimeout(()=>{N()},800)},H=()=>{const t=`
  body {
    margin: 0;
    height: 100vh;
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
  }

  pre {
    height: 0 !important;
    display: none !important;
  }

  .error-line-highlight {
    background-color: rgba(255, 13, 0, 0.41);
  }

  .error-gutter-icon::before {
    content: '🦝';
    font-size: 16px;
    line-height: 1;
    display: inline-block;
    width: 100%;
    transform: scaleX(-1);
    text-align: center;
  }

  .my-inline-tooltip::after {
    content: '👉';
    display: inline-block;
    animation: point 0.8s ease-in-out infinite;
    transform-origin: center right;
  }

  @keyframes point {
    0%, 100% {
      transform: translateX(-4px);
    }
    50% {
      transform: translateX(0px);
    }
  }

  .dialog-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.3);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
  }

  .dialog {
    background: rgba(227, 227, 227, 1);
    padding: 1rem 1.5rem;
    border-radius: 8px;
    max-width: 300px;
    color: rgba(17, 0, 24, 1);
    border-top: 5px solid transparent;
    width: 100%;
    box-shadow: 0 4px 20px rgba(0,0,0,0.2);
    text-align: center;
  }

  .warn {
    border-top: 5px solid orange;
  }

  .error {
    border-top: 5px solid red;
  }

  .dialog-issues-url {
    text-decoration: none;
    margin-bottom: 16px;
    color: #b047caff;
  }

  .button {
    padding: 8px 25px;
    margin: 4px;
    border: 4px solid #333;
    border-radius: 12px;
    background-color: #f0f0f0;
    color: #333;
    font-size: 11px;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 1px;
    cursor: pointer;
    box-shadow: 0px 8px 0px #000;
    transition: all 0.2s ease;
    outline: none;
}

  .button:disabled {
      pointer-events: none;
      background: lightgray;
      cursor: not-allowed;
      color: #5b5b5b;
      box-shadow: 0px 4px 0px #575757;
  }

  .button:hover {
      background-color: #b047caff;
      box-shadow: 0px 4px 0px #000;
      transform: translateY(4px);
  }

  .button:active {
      background-color: #e0e0e0;
      box-shadow: 0px 0px 0px #000;
      transform: translateY(8px);
  }

  .status-bar {
      padding-left: 9px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      z-index: 100;
      width: 100vw;
      height: 30px;
      bottom: 0;
      position: fixed;
      background-image: linear-gradient(90deg, #b047caff, #38074dff, #2f00ffff);
      background-size: 400% 100%;
      animation: gradient-animation 15s ease infinite alternate;
  }

  .cooper {
    width: 200px;
  }
  
  .splash-page {
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    background: ${k()?v.DARK.BACKGROUND:v.LIGHT.BACKGROUND} ;
    position: absolute;
    height: 100%;
    display: flex;
    z-index: 10001;
  }

  .splash-logo {
    width: 420px;
  }

  .bubble {
      position: relative;
      background: #ffffff;
      color: #5d0970;
      font-family: Arial;
      font-size: 1rem;
      line-height: 35px;
      box-shadow: 0px 0px 39px 0px #000);
      text-align: center;
      border-radius: 27px;
      padding: 0px 18px;
  }

  .bubble:after {
      content: '';
      position: absolute;
      display: block;
      width: 0;
      z-index: 1;
      border-style: solid;
      border-color: #ffffff transparent;
      border-width: 20px 10px 0;
      bottom: -20px;
      left: 50%;
      margin-left: -20px;
  }

  .splash-loading-text {
    animation: breathing 1s ease-in-out infinite alternate;
  }

    @keyframes gradient-animation {
      0% {
          background-position: 0% 50%;
      }
      50% {
          background-position: 100% 50%;
      }
      100% {
          background-position: 0% 50%;
      }
  }

  @keyframes breathing {
    0% {
      transform: scale(0.9);
    }
    50% {
      transform: scale(1);
    }
    100% {
      transform: scale(0.9);
    }
  }




`,e=document.createElement("style");e.id="🦝💅",e.type="text/css",e.innerText=t,document.head.appendChild(e)},I=t=>/\.js:\d+:\d+$/.test(t),G=async t=>{try{const e=await fetch(t,{cache:"no-store"});e.ok||console.error(`HTTP ${e.status}`);const o=e.headers.get("content-type");return o&&!o.includes("javascript")?null:await e.text()}catch(e){return console.error("Failed to fetch from URL:",{url:t,exception:e}),null}},K=()=>{const t=document.head.appendChild;document.head.appendChild=function(e){if(e instanceof HTMLLinkElement&&e.href&&e.href.includes(window.location.origin+"/assets/")){const o=chrome.runtime.getURL("/"),r=e.href.toString().split("/").pop(),s=o+"assets/"+r;e.href=s}return t.call(document.head,e)}},J=t=>{const e=t.match(/^(.*):(\d+):(\d+)$/);if(!e)return{baseUrl:t};const[,o,n,r]=e;return{baseUrl:o,line:parseInt(n,10),column:parseInt(r,10)}},f=window.location.href;if(I(f)||U(f)){let t=f;const e={line:null,column:null};if(I(f)){const r=J(f);t=r.baseUrl,r.line&&r.column&&(e.line=r.line,e.column=r.column)}const o=await G(t),n=!!e.line&&!!e.column;o&&(M(),H(),O(),K(),z({sourceCode:o,enableCursor:n,initialLineNumber:e.line||1,initialColNumber:e.column||1}))}export{b as _};
