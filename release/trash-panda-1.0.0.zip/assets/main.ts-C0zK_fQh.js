const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/editor.main-CNTsZimW.js","assets/monaco-editor.css"])))=>i.map(i=>d[i]);
import{T as b,D as O}from"./default-racoon-colour-C6zlquoW.js";const T=n=>n.endsWith(".js"),w=[{hex:"#CD5C5C",name:"INDIANRED",rgb:"RGB(205, 92, 92)",families:["red","brown"]},{hex:"#F08080",name:"LIGHTCORAL",rgb:"RGB(240, 128, 128)",families:["red","pink","coral","light"]},{name:"SALMON",hex:"#FA8072",rgb:"RGB(250, 128, 114)",families:["red","pink","orange","salmon"]},{hex:"#E9967A",name:"DARKSALMON",rgb:"RGB(233, 150, 122)",families:["red","pink","orange","salmon","dark"]},{hex:"#FFA07A",name:"LIGHTSALMON",rgb:"RGB(255, 160, 122)",families:["red","pink","orange","salmon","light"]},{hex:"#DC143C",name:"CRIMSON",families:["red"],rgb:"RGB(220, 20, 60)"},{name:"RED",hex:"#FF0000",families:["red"],rgb:"RGB(255, 0, 0)"},{name:"PINK",hex:"#FFC0CB",families:["pink"],rgb:"RGB(255, 192, 203)"},{hex:"#FFB6C1",name:"LIGHTPINK",rgb:"RGB(255, 182, 193)",families:["pink","light"]},{hex:"#FF69B4",name:"HOTPINK",rgb:"RGB(255, 105, 180)",families:["pink","hot"]},{hex:"#FF1493",name:"DEEPPINK",rgb:"RGB(255, 20, 147)",families:["pink","deep"]},{hex:"#DB7093",name:"PALEVIOLETRED",rgb:"RGB(219, 112, 147)",families:["pink","pale","violet"]},{name:"CORAL",hex:"#FF7F50",rgb:"RGB(255, 127, 80)",families:["orange","coral"]},{name:"TOMATO",hex:"#FF6347",rgb:"RGB(255, 99, 71",families:["orange","red"]},{hex:"#FF4500",name:"ORANGERED",rgb:"RGB(255, 69, 0)",families:["orange","red"]},{hex:"#FF8C00",name:"DARKORANGE",rgb:"RGB(255, 140, 0)",families:["orange","dark"]},{name:"ORANGE",hex:"#FFA500",families:["orange"],rgb:"RGB(255, 165, 0)"},{name:"GOLD",hex:"#FFD700",families:["yellow"],rgb:"RGB(255, 215, 0)"},{name:"YELLOW",hex:"#FFFF00",families:["yellow"],rgb:"RGB(255, 255, 0)"},{hex:"#FFFFE0",name:"LIGHTYELLOW",rgb:"RGB(255, 255, 224)",families:["yellow","light"]},{hex:"#FFFACD",name:"LEMONCHIFFON",rgb:"RGB(255, 250, 205)",families:["yellow","lemon"]},{hex:"#FAFAD2",rgb:"RGB(250, 250, 210)",name:"LIGHTGOLDENRODYELLOW",families:["yellow","light","goldenrod","tan"]},{hex:"#FFEFD5",name:"PAPAYAWHIP",rgb:"RGB(255, 239, 213)",families:["pink","tan"]},{hex:"#FFE4B5",name:"MOCCASIN",rgb:"RGB(255, 228, 181)",families:["pink","tan"]},{hex:"#FFDAB9",name:"PEACHPUFF",rgb:"RGB(255, 218, 185)",families:["pink","orange","peach"]},{hex:"#EEE8AA",name:"PALEGOLDENROD",rgb:"RGB(238, 232, 170)",families:["yellow","tan","pale","goldenrod"]},{name:"KHAKI",hex:"#F0E68C",rgb:"RGB(240, 230, 140)",families:["yellow","tan","khaki"]},{hex:"#BDB76B",name:"DARKKHAKI",rgb:"RGB(189, 183, 107)",families:["yellow","tan","khaki","dark"]},{hex:"#E6E6FA",name:"LAVENDER",families:["purple"],rgb:"RGB(230, 230, 250)"},{hex:"#D8BFD8",name:"THISTLE",families:["purple"],rgb:"RGB(216, 191, 216)"},{name:"PLUM",hex:"#DDA0DD",families:["purple"],rgb:"RGB(221, 160, 221)"},{name:"VIOLET",hex:"#EE82EE",rgb:"RGB(238, 130, 238)",families:["purple","violet","pink"]},{name:"ORCHID",hex:"#DA70D6",rgb:"RGB(218, 112, 214)",families:["purple","orchid"]},{hex:"#FF00FF",name:"FUCHSIA",rgb:"RGB(255, 0, 255)",families:["purple","pink"]},{hex:"#FF00FF",name:"MAGENTA",rgb:"RGB(255, 0, 255)",families:["purple","pink","magenta"]},{hex:"#BA55D3",name:"MEDIUMORCHID",rgb:"RGB(186, 85, 211)",families:["purple","orchid","medium"]},{hex:"#9370DB",name:"MEDIUMPURPLE",rgb:"RGB(147, 112, 219)",families:["purple","medium"]},{hex:"#6A5ACD",name:"SLATEBLUE",rgb:"RGB(106, 90, 205)",families:["purple","blue","slate"]},{hex:"#7B68EE",name:"MEDIUMSLATEBLUE",rgb:"RGB(123, 104, 238)",families:["purple","blue","slate","medium"]},{hex:"#ADFF2F",name:"GREENYELLOW",rgb:"RGB(173, 255, 47)",families:["green","yellow"]},{hex:"#7FFF00",name:"CHARTREUSE",families:["green"],rgb:"RGB(127, 255, 0)"},{hex:"#7CFC00",name:"LAWNGREEN",families:["green"],rgb:"RGB(124, 252, 0)"},{name:"LIME",hex:"#00FF00",families:["green"],rgb:"RGB(0, 255, 0)"},{hex:"#32CD32",name:"LIMEGREEN",families:["green"],rgb:"RGB(50, 205, 50)"},{hex:"#98FB98",name:"PALEGREEN",rgb:"RGB(152, 251, 152)",families:["green","pale"]},{hex:"#90EE90",name:"LIGHTGREEN",rgb:"RGB(144, 238, 144)",families:["green","light"]},{hex:"#00FA9A",rgb:"RGB(0, 250, 154)",name:"MEDIUMSPRINGGREEN",families:["green","medium","spring"]},{hex:"#00FF7F",name:"SPRINGGREEN",rgb:"RGB(0, 255, 127)",families:["green","spring"]},{hex:"#3CB371",name:"MEDIUMSEAGREEN",rgb:"RGB(60, 179, 113)",families:["green","sea","medium"]},{hex:"#2E8B57",name:"SEAGREEN",rgb:"RGB(46, 139, 87)",families:["green","sea"]},{hex:"#228B22",name:"FORESTGREEN",rgb:"RGB(34, 139, 34)",families:["green","forest"]},{hex:"#9ACD32",name:"YELLOWGREEN",rgb:"RGB(154, 205, 50)",families:["green","yellow"]},{name:"OLIVE",hex:"#6B8E23",rgb:"RGB(128, 128, 0)",families:["green","olive"]},{hex:"#66CDAA",name:"MEDIUMAQUAMARINE",rgb:"RGB(102, 205, 170)",families:["green","blue","aquamarine","medium"]},{hex:"#8FBC8B",name:"DARKSEAGREEN",rgb:"RGB(143, 188, 139)",families:["green","sea","dark"]},{hex:"#20B2AA",name:"LIGHTSEAGREEN",rgb:"RGB(32, 178, 170)",families:["green","blue","sea","light"]},{name:"AQUA",hex:"#00FFFF",rgb:"RGB(0, 255, 255)",families:["blue","aqua"]},{name:"CYAN",hex:"#00FFFF",rgb:"RGB(0, 255, 255)",families:["blue","cyan"]},{hex:"#E0FFFF",name:"LIGHTCYAN",rgb:"RGB(224, 255, 255)",families:["blue","cyan","light"]},{hex:"#AFEEEE",name:"PALETURQUOISE",rgb:"RGB(175, 238, 238)",families:["blue","turquoise","pale"]},{hex:"#7FFFD4",name:"AQUAMARINE",rgb:"RGB(127, 255, 212)",families:["blue","aquamarine"]},{hex:"#40E0D0",name:"TURQUOISE",rgb:"RGB(64, 224, 208)",families:["blue","turquoise"]},{hex:"#48D1CC",name:"MEDIUMTURQUOISE",rgb:"RGB(72, 209, 204)",families:["blue","turquoise","medium"]},{hex:"#00CED1",name:"DARKTURQUOISE",rgb:"RGB(0, 206, 209)",families:["blue","turquoise","dark"]},{hex:"#5F9EA0",name:"CADETBLUE",rgb:"RGB(95, 158, 160)",families:["blue","gray"]},{hex:"#B0C4DE",name:"LIGHTSTEELBLUE",rgb:"RGB(176, 196, 222)",families:["blue","steel","light"]},{hex:"#B0E0E6",name:"POWDERBLUE",families:["blue"],rgb:"RGB(176, 224, 230)"},{hex:"#ADD8E6",name:"LIGHTBLUE",rgb:"RGB(173, 216, 230)",families:["blue","light"]},{hex:"#87CEEB",name:"SKYBLUE",rgb:"RGB(135, 206, 235)",families:["blue","sky"]},{hex:"#87CEFA",name:"LIGHTSKYBLUE",rgb:"RGB(135, 206, 250)",families:["blue","sky","light"]},{hex:"#00BFFF",name:"DEEPSKYBLUE",rgb:"RGB(0, 191, 255)",families:["blue","sky","deep"]},{hex:"#1E90FF",name:"DODGERBLUE",families:["blue"],rgb:"RGB(30, 144, 255)"},{hex:"#6495ED",families:["blue"],name:"CORNFLOWERBLUE",rgb:"RGB(100, 149, 237)"},{hex:"#4169E1",name:"ROYALBLUE",families:["blue"],rgb:"RGB(65, 105, 225)"},{hex:"#FFF8DC",name:"CORNSILK",rgb:"RGB(255, 248, 220)",families:["brown","tan"]},{hex:"#FFEBCD",name:"BLANCHEDALMOND",rgb:"RGB(255, 235, 205)",families:["brown","tan"]},{name:"BISQUE",hex:"#FFE4C4",rgb:"RGB(255, 228, 196)",families:["brown","tan"]},{hex:"#FFDEAD",name:"NAVAJOWHITE",rgb:"RGB(255, 222, 173)",families:["brown","tan"]},{name:"WHEAT",hex:"#F5DEB3",rgb:"RGB(245, 222, 179)",families:["brown","tan"]},{hex:"#DEB887",name:"BURLYWOOD",rgb:"RGB(222, 184, 135)",families:["brown","tan"]},{name:"TAN",hex:"#D2B48C",rgb:"RGB(210, 180, 140)",families:["brown","tan"]},{hex:"#BC8F8F",name:"ROSYBROWN",rgb:"RGB(188, 143, 143)",families:["brown","tan"]},{hex:"#F4A460",name:"SANDYBROWN",rgb:"RGB(244, 164, 96)",families:["brown","orange"]},{hex:"#DAA520",name:"GOLDENROD",rgb:"RGB(218, 165, 32)",families:["brown","goldenrod","orange"]},{hex:"#B8860B",name:"DARKGOLDENROD",rgb:"RGB(184, 134, 11)",families:["brown","orange","goldenrod","dark"]},{name:"PERU",hex:"#CD853F",rgb:"RGB(205, 133, 63)",families:["brown","orange"]},{hex:"#D2691E",name:"CHOCOLATE",rgb:"RGB(210, 105, 30)",families:["brown","orange"]},{name:"SIENNA",hex:"#A0522D",families:["brown"],rgb:"RGB(160, 82, 45)"},{name:"WHITE",hex:"#FFFFFF",families:["white"],rgb:"RGB(255, 255, 255)"},{name:"SNOW",hex:"#FFFAFA",families:["white"],rgb:"RGB(255, 250, 250)"},{hex:"#F0FFF0",name:"HONEYDEW",families:["white"],rgb:"RGB(240, 255, 240)"},{hex:"#F5FFFA",name:"MINTCREAM",families:["white"],rgb:"RGB(245, 255, 250)"},{name:"AZURE",hex:"#F0FFFF",families:["white"],rgb:"RGB(240, 255, 255)"},{hex:"#F0F8FF",name:"ALICEBLUE",families:["white"],rgb:"RGB(240, 248, 255)"},{hex:"#F8F8FF",name:"GHOSTWHITE",families:["white"],rgb:"RGB(248, 248, 255)"},{hex:"#F5F5F5",name:"WHITESMOKE",families:["white"],rgb:"RGB(245, 245, 245)"},{hex:"#FFF5EE",name:"SEASHELL",rgb:"RGB(255, 245, 238)",families:["white","pink"]},{name:"BEIGE",hex:"#F5F5DC",rgb:"RGB(245, 245, 220)",families:["white","tan"]},{hex:"#FDF5E6",name:"OLDLACE",rgb:"RGB(253, 245, 230)",families:["white","tan"]},{hex:"#FDF5E6",name:"FLORALWHITE",rgb:"RGB(253, 245, 230)",families:["white","tan"]},{name:"IVORY",hex:"#FFFFF0",rgb:"RGB(255, 255, 240)",families:["white","tan"]},{hex:"#FAEBD7",name:"ANTIQUEWHITE",rgb:"RGB(250, 235, 215)",families:["white","tan"]},{name:"LINEN",hex:"#FAF0E6",rgb:"RGB(250, 240, 230)",families:["white","tan"]},{hex:"#FFF0F5",name:"LAVENDERBLUSH",rgb:"RGB(255, 240, 245)",families:["white","lavender","pink"]},{hex:"#FFE4E1",name:"MISTYROSE",rgb:"RGB(255, 228, 225)",families:["white","pink"]},{hex:"#DCDCDC",name:"GAINSBORO",families:["gray"],rgb:"RGB(220, 220, 220)"},{hex:"#D3D3D3",name:"LIGHTGRAY",rgb:"RGB(211, 211, 211)",families:["gray","light"]},{name:"SILVER",hex:"#C0C0C0",families:["gray"],rgb:"RGB(192, 192, 192)"},{hex:"#A9A9A9",name:"DARKGRAY",rgb:"RGB(169, 169, 169)",families:["gray","dark"]},{name:"GRAY",hex:"#808080",families:["gray"],rgb:"RGB(128, 128, 128)"},{hex:"#778899",name:"LIGHTSLATEGRAY",rgb:"RGB(119, 136, 153)",families:["gray","light","slate"]},{hex:"#708090",name:"SLATEGRAY",rgb:"RGB(112, 128, 144)",families:["gray","slate"]},{hex:"#2F4F4F",name:"DARKSLATEGRAY",rgb:"RGB(47, 79, 79)",families:["gray","slate","dark"]},{name:"BLACK",hex:"#000000",rgb:"RGB(0, 0, 0)",families:["black"]}],N=()=>{for(document.querySelectorAll('style, link[rel="stylesheet"]').forEach(n=>n.remove());document.body.firstChild;)document.body.removeChild(document.body.firstChild);document.documentElement.removeAttribute("style"),document.body.removeAttribute("style"),document.body.style.background=b.LIGHT.BACKGROUND},B=-100,G=50,v="rgb(0,0,255)",U="rgb(0,255,0)",M="rgb(255,0,0)",_=(n,e)=>{const[r,t,a]=e.toLowerCase().replace("rgb(","").replaceAll(")","").split(",").map(o=>Number(o)),i=`rgb(${r+B},${t+B+30},${a+B-30})`,s=`rgb(${r+G+30},${t+G+0},${a+G+30})`,l=`rgb(${r},${t},${a})`;return n.replaceAll(v,l).replaceAll(U,s).replaceAll(M,i)},H=["Who’s fault was it?","Blame someone, anyone.","Oops. Not again.","I test in prod","Another day, another disaster.","Someone’s in trouble.","I’ve seen worse… maybe.","Who wrote this?","I wonder if McDonalds is hiring.","What does grass feel like?","Someone check the stock market.","Who let this function exist?","Callbacks are a war crime.","I’m a JS dev, send help.","My life is just callbacks and regrets.","My brain is a garbage collected heap.","The only constant is undefined.","undefined is my spirit animal.","My stack trace knows more about me than I do.","The only thing constant is my regret.","Who even invented modules?","I’m the main character in someone else’s bug report.","Another day, another Stack Overflow spiral.","I’m 80% caffeine, 20% regret.","Somehow I get paid for this.","Every deployment is a personal gamble.","There’s always one more framework.","Does anyone else feel like this or am I cursed.","They told me I’d ship features, not despair.","Is this what adulthood feels like?","Mamma mia, time for some spaghetti.","Sometimes I wonder if I’m the bug.","Is it too late to quit?","My mental stack overflows daily.","I ship despair in 2KB chunks.","Every bug is a personal insult.","I consider burning my laptop ritualistically.","My brain just threw a runtime error.","Whats vitamin D?","Fanculo a questi spaghetti.","Theres no honour in fixing this nightmare.","Yep, this definitely looks maintainable.","Ah yes, so this is what clean code looks like.","Oh look, another utils.js with 5,000 lines, beautiful.","Yep, everything is “modular,” except when it isn’t.","So much for single responsibility, this file is responsible for my breakdown.","This techdebt has techdebt.","Whoever wrote this should be on a watchlist.","Is spaghetti an official design pattern now?","This code smells like unpaid internships.","Clean coding principles? More like Stockholm syndrome principles.","I’ve seen ransom notes more readable than this.","This promise chain looks like a cry for help.","I should rename this file footgun.js.","Let's rewrite this in Rust.","I'm gonna pop a blood vessel.","Cry :(","Time to update my LinkedIn profile.","Strike two.","How am I going to explain the gap on my resume?","I'm hope your company covers therapy.","This must have been written by a 10x developer.","I thought Typescript was supposed to catch runtime errors."],P=async n=>{const e=document.createElement("div");e.className="splash-page";const t=await(await fetch(chrome.runtime.getURL("cooper-munching.svg"))).text(),a=_(t,n),i=encodeURIComponent(a);e.innerHTML=`
    <img class="splash-logo" src="${chrome.runtime.getURL("trash-logo.svg")}">
    <h2 class="splash-loading-text">Loading</h2>
    <br><br><br><br>
    <div class="bubble">
      ${H.sort(()=>Math.random()-.5)[0]}
    </div>
    <img class="cooper" src="${`data:image/svg+xml,${i}`}">
    <br>
  `,document.body.appendChild(e)},W="modulepreload",K=function(n){return"/"+n},D={},E=function(e,r,t){let a=Promise.resolve();if(r&&r.length>0){let s=function(o){return Promise.all(o.map(h=>Promise.resolve(h).then(u=>({status:"fulfilled",value:u}),u=>({status:"rejected",reason:u}))))};document.getElementsByTagName("link");const l=document.querySelector("meta[property=csp-nonce]"),d=l?.nonce||l?.getAttribute("nonce");a=s(r.map(o=>{if(o=K(o),o in D)return;D[o]=!0;const h=o.endsWith(".css"),u=h?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${o}"]${u}`))return;const m=document.createElement("link");if(m.rel=h?"stylesheet":W,h||(m.as="script"),m.crossOrigin="",m.href=o,d&&m.setAttribute("nonce",d),document.head.appendChild(m),h)return new Promise((A,x)=>{m.addEventListener("load",A),m.addEventListener("error",()=>x(new Error(`Unable to preload CSS for ${o}`)))})}))}function i(s){const l=new Event("vite:preloadError",{cancelable:!0});if(l.payload=s,window.dispatchEvent(l),!l.defaultPrevented)throw s}return a.then(s=>{for(const l of s||[])l.status==="rejected"&&i(l.reason);return e().catch(i)})},k=()=>!!(window.matchMedia("(prefers-color-scheme: dark)").matches||window.matchMedia("(prefers-color-scheme: no-preference)").matches),C=({type:n,title:e,message:r})=>{const t=document.createElement("div");t.className="dialog-overlay";const a=document.createElement("div");a.className=`dialog ${n}`,a.innerHTML=`
    <h1>${e}</h1>
    <p>${r}</p>
    
    <button class="dialog-close button">Close</button>
  `,t.appendChild(a),document.body.appendChild(t);const i=()=>t.remove();t.addEventListener("click",s=>{s.target===t&&i()}),a.querySelector(".dialog-close")?.addEventListener("click",i)},$=()=>{const n=document.querySelector(".splash-page");n&&n.remove()},Y={onerror:null,getWorker(){},terminate(){},onmessage:null,postMessage(){},addEventListener(){},removeEventListener(){},dispatchEvent:()=>!1},j=()=>{self.MonacoEnvironment={getWorker(n,e){return Y}}},q=(n,e,r)=>{const t=n.split(`
`);let a=0;for(let i=0;i<e-1;i++)a+=t[i].length+1;return a+(r-1)},V=()=>{const n=document.createElement("div");n.className="status-wrapper";const e=document.createElement("footer");e.className="status-bar",n.appendChild(e),document.body.appendChild(n)},z=async({code:n,cursorOffset:e})=>{const{formatWithCursor:r}=await E(async()=>{const{formatWithCursor:s}=await import("./standalone-C-enP7Mo.js");return{formatWithCursor:s}},[]),t=(await E(async()=>{const{default:s}=await import("./estree-BKUavBKs.js");return{default:s}},[])).default,a=await E(()=>import("./babel-nAzM5Yej.js"),[]);return await r(n,{cursorOffset:e,parser:"babel",plugins:[a,t]})},Q=n=>n.split(/\r?\n/).map(e=>e.length),J=async({sourceCode:n,enableCursor:e,initialColNumber:r,initialLineNumber:t})=>{const a=await E(()=>import("./editor.main-CNTsZimW.js").then(f=>f.e),__vite__mapDeps([0,1])),{Range:i,editor:s,Selection:l}=a,d=n,o=Q(d),h=Math.max(...o),u=o.length;let m=!0;t>u&&(C({type:"warn",title:"Out of range",message:`Line number ${t} is beyond the total line count`}),m=!1),o[t-1]<r&&(C({type:"warn",title:"Out of range",message:`Line ${t} has a max character count of ${o[t-1]}, you provided ${r}`}),m=!1);const x=m?q(d,t,r):1,y=await z({code:d,cursorOffset:x}),L=document.createElement("div");L.id="editor",document.body.appendChild(L);const F=document.getElementById("editor");F.style.height="calc(100vh - 20px)",F.style.width="100vw",j();const g=s.create(F,{readOnly:!0,glyphMargin:!0,automaticLayout:!0,language:"javascript",value:y.formatted,theme:k()?"vs-dark":"vs",maxTokenizationLineLength:h});if(V(),g.onMouseDown(f=>{f.target.type===a.editor.MouseTargetType.CONTENT_TEXT&&g.trigger("","editor.action.revealDefinition",{})}),m&&e){const c=g.getModel().getPositionAt(y.cursorOffset);g.createDecorationsCollection([{range:new i(c.lineNumber,c.column,c.lineNumber,c.column),options:{beforeContentClassName:"my-inline-tooltip",hoverMessage:{value:`⚠️ Stack trace location ${t}:${r} ⚠️`}}}]),g.revealPositionInCenter(c);const S=g.getModel().getLineLength(c.lineNumber);g.setSelection(new l(c.lineNumber,1,c.lineNumber,S+1)),g.createDecorationsCollection([{range:new i(c.lineNumber,1,c.lineNumber,1),options:{isWholeLine:!0,className:"error-line-highlight",glyphMarginClassName:"error-gutter-icon"}}])}setTimeout(()=>{$()},500)},X=()=>{const n=`
  body {
    margin: 0;
    height: 100vh;
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
  }

  pre {
    height: 0 !important;
    display: none !important;
  }

  .error-line-highlight {
    background-color: rgba(255, 13, 0, 0.41);
  }

  .error-gutter-icon::before {
    content: '🦝';
    font-size: 16px;
    line-height: 1;
    display: inline-block;
    width: 100%;
    transform: scaleX(-1);
    text-align: center;
  }

  .my-inline-tooltip::after {
    content: '👉';
    display: inline-block;
    animation: point 0.8s ease-in-out infinite;
    transform-origin: center right;
  }

  @keyframes point {
    0%, 100% {
      transform: translateX(-4px);
    }
    50% {
      transform: translateX(0px);
    }
  }

  .dialog-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.3);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
  }

  .dialog {
    background: rgba(227, 227, 227, 1);
    padding: 1rem 1.5rem;
    border-radius: 8px;
    max-width: 300px;
    color: rgba(17, 0, 24, 1);
    border-top: 5px solid transparent;
    width: 100%;
    box-shadow: 0 4px 20px rgba(0,0,0,0.2);
    text-align: center;
  }

  .warn {
    border-top: 5px solid orange;
  }

  .error {
    border-top: 5px solid red;
  }

  .dialog-issues-url {
    text-decoration: none;
    margin-bottom: 16px;
    color: #b047caff;
  }

  .button {
    padding: 8px 25px;
    margin: 4px;
    border: 4px solid #333;
    border-radius: 12px;
    background-color: #f0f0f0;
    color: #333;
    font-size: 11px;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 1px;
    cursor: pointer;
    box-shadow: 0px 8px 0px #000;
    transition: all 0.2s ease;
    outline: none;
}

  .button:disabled {
      pointer-events: none;
      background: lightgray;
      cursor: not-allowed;
      color: #5b5b5b;
      box-shadow: 0px 4px 0px #575757;
  }

  .button:hover {
      background-color: #b047caff;
      box-shadow: 0px 4px 0px #000;
      transform: translateY(4px);
  }

  .button:active {
      background-color: #e0e0e0;
      box-shadow: 0px 0px 0px #000;
      transform: translateY(8px);
  }

  .status-bar {
      padding-left: 9px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      z-index: 100;
      width: 100vw;
      height: 30px;
      bottom: 0;
      position: fixed;
      background-image: linear-gradient(90deg, ${b.DARK.BACKGROUND}, #38074dff, #ba0fb4ff);
      background-size: 400% 100%;
      animation: gradient-animation 35s ease infinite alternate;
  }

  .cooper {
    width: 300px;
  }
  
  .splash-page {
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    background: ${k()?b.DARK.BACKGROUND:b.LIGHT.BACKGROUND} ;
    position: absolute;
    height: 100%;
    display: flex;
    z-index: 10001;
  }

  .splash-logo {
    width: 420px;
  }

  .bubble {
      position: relative;
      background: #ffffff;
      color: #5d0970;
      font-family: Arial;
      font-size: 1rem;
      line-height: 35px;
      box-shadow: 0px 0px 39px 0px #000);
      text-align: center;
      border-radius: 27px;
      padding: 0px 18px;
  }

  .bubble:after {
      content: '';
      position: absolute;
      display: block;
      width: 0;
      z-index: 1;
      border-style: solid;
      border-color: #ffffff transparent;
      border-width: 20px 10px 0;
      bottom: -20px;
      left: 50%;
      margin-left: -20px;
  }

  .splash-loading-text {
    animation: breathing 1s ease-in-out infinite alternate;
  }

    @keyframes gradient-animation {
      0% {
          background-position: 0% 50%;
      }
      50% {
          background-position: 100% 50%;
      }
      100% {
          background-position: 0% 50%;
      }
  }

  @keyframes breathing {
    0% {
      transform: scale(0.9);
    }
    50% {
      transform: scale(1);
    }
    100% {
      transform: scale(0.9);
    }
  }




`,e=document.createElement("style");e.id="🦝💅",e.type="text/css",e.innerText=n,document.head.appendChild(e)},I=n=>/\.js:\d+:\d+$/.test(n),Z=async n=>{try{const e=await fetch(n,{cache:"no-store"});if(!e.ok)return console.error(`HTTP ${e.status}`),null;const r=e.headers.get("content-type");return r&&!r.includes("javascript")?null:await e.text()}catch(e){return console.error("Failed to fetch from URL:",{url:n,exception:e}),null}},ee=()=>{const n=document.head.appendChild;document.head.appendChild=function(e){if(e instanceof HTMLLinkElement&&e.href&&e.href.includes(window.location.origin+"/assets/")){const r=chrome.runtime.getURL("/"),a=e.href.toString().split("/").pop(),i=r+"assets/"+a;e.href=i}return n.call(document.head,e)}},ne=()=>{chrome.runtime.onMessage.addListener((n,e,r)=>{if(n.type==="GET_COLOUR"){const t=window?.__trash_panda?.currentRacoonColor||O;return r({color:t}),!0}})},te=(n,e,r=0)=>{const t=Math.sin(n)*1e4,a=t-Math.floor(t);return Math.floor(a*(e-r+1))+r},ae=n=>{const e=n.match(/^(.*):(\d+):(\d+)$/);if(!e)return{baseUrl:n};const[,r,t,a]=e;return{baseUrl:r,line:parseInt(t,10),column:parseInt(a,10)}};let R=O;window.__trash_panda={currentRacoonColor:R};ne();const p=window.location.href;if(I(p)||T(p)){let n=p;const e={line:null,column:null};if(I(p)){const a=ae(p);n=a.baseUrl,a.line&&a.column&&(e.line=a.line,e.column=a.column)}const r=await Z(n),t=!!e.line&&!!e.column;if(e.line&&e.column){const a=te(e.line+e.column,w.length-1);R=w[a].rgb}window.__trash_panda.currentRacoonColor=R,r&&(N(),X(),P(R),ee(),J({sourceCode:r,enableCursor:t,initialLineNumber:e.line||1,initialColNumber:e.column||1}))}export{E as _};
