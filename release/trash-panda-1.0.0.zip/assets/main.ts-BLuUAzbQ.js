const i=()=>{chrome.runtime.onMessage.addListener((e,t)=>{e.type==="GET_COLOUR"&&t.tab?.id&&chrome.scripting.executeScript({files:["content.js"],target:{tabId:t.tab.id}})})};i();
