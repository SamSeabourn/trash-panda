const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/editor.main-DzJzVBav.js","assets/monaco-editor.css"])))=>i.map(i=>d[i]);
const P=e=>e.endsWith(".js"),O="modulepreload",M=function(e){return"/"+e},S={},b=function(t,n,o){let r=Promise.resolve();if(n&&n.length>0){let l=function(c){return Promise.all(c.map(p=>Promise.resolve(p).then(u=>({status:"fulfilled",value:u}),u=>({status:"rejected",reason:u}))))};document.getElementsByTagName("link");const a=document.querySelector("meta[property=csp-nonce]"),g=(a==null?void 0:a.nonce)||(a==null?void 0:a.getAttribute("nonce"));r=l(n.map(c=>{if(c=M(c),c in S)return;S[c]=!0;const p=c.endsWith(".css"),u=p?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${c}"]${u}`))return;const i=document.createElement("link");if(i.rel=p?"stylesheet":O,p||(i.as="script"),i.crossOrigin="",i.href=c,g&&i.setAttribute("nonce",g),document.head.appendChild(i),p)return new Promise((w,y)=>{i.addEventListener("load",w),i.addEventListener("error",()=>y(new Error(`Unable to preload CSS for ${c}`)))})}))}function s(l){const a=new Event("vite:preloadError",{cancelable:!0});if(a.payload=l,window.dispatchEvent(a),!a.defaultPrevented)throw l}return r.then(l=>{for(const a of l||[])a.status==="rejected"&&s(a.reason);return t().catch(s)})},k=({type:e,title:t,message:n})=>{var l;const o=document.createElement("div");o.className="dialog-overlay";const r=document.createElement("div");r.className=`dialog ${e}`,r.innerHTML=`
    <h1>${t}</h1>
    <p>${n}</p>
    ${e==="error"?'<p><a class="dialog-issues-url" href="https://github.com/SamSeabourn/trash-panda/issues" target="_blank">Please report here</a></p>':""}
    <button class="dialog-close button">Close</button>
  `,o.appendChild(r),document.body.appendChild(o);const s=()=>o.remove();o.addEventListener("click",a=>{a.target===o&&s()}),(l=r.querySelector(".dialog-close"))==null||l.addEventListener("click",s)},v=e=>{const t=`importScripts("${e}");`,n=new Blob([t],{type:"application/javascript"}),o=URL.createObjectURL(n);return new Worker(o,{type:"classic"})},T=()=>{self.MonacoEnvironment={getWorker(e,t){return t==="typescript"||t==="javascript"?v(chrome.runtime.getURL("assets/monaco-workers/ts.worker.bundle.js")):t==="html"?v(chrome.runtime.getURL("assets/monaco-workers/html.worker.bundle.js")):t==="editorWorkerService"?v(chrome.runtime.getURL("assets/monaco-workers/editor.worker.bundle.js")):()=>({terminate(){},postMessage(){},addEventListener(){},removeEventListener(){},dispatchEvent(){return!1}})}}},j=(e,t,n)=>{const o=e.split(`
`);let r=0;for(let s=0;s<t-1;s++)r+=o[s].length+1;return r+(n-1)},I=e=>e.split(/\r?\n/).map(t=>t.length),_=async(e=1,t=1,n=!0)=>{const o=document.querySelector("pre");if(!o){console.warn("No <pre> tag found on the page.");return}const r=await b(()=>import("./editor.main-DzJzVBav.js").then(h=>h.e),__vite__mapDeps([0,1])),{Range:s,editor:l,Selection:a}=r,g=(await b(async()=>{const{default:h}=await import("./estree-DZUM3lmb.js");return{default:h}},[])).default,c=await b(()=>import("./babel-CqqbTYm7.js"),[]),{formatWithCursor:p}=await b(async()=>{const{formatWithCursor:h}=await import("./standalone-CmLo_iCX.js");return{formatWithCursor:h}},[]),u=o.textContent??"",i=I(u),w=i.sort()[0],y=i.length;let f=!0;e>y&&(k({type:"warn",title:"Out of range",message:`Line number ${e} is beyond the total line count`}),f=!1),i[e-1]<t&&(k({type:"warn",title:"Out of range",message:`Line ${e} has a max coloumn size of ${i[e-1]}, you provided ${t}`}),f=!1);const N=f?j(u,e,t):1,L=await p(u,{cursorOffset:N,parser:"babel",plugins:[c,g]}),E=document.createElement("div");E.id="editor",document.body.appendChild(E);const x=document.getElementById("editor");x.style.height="100vh",x.style.width="100vw";const R=window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches;T();const m=l.create(x,{readOnly:!0,glyphMargin:!0,automaticLayout:!0,language:"javascript",value:L.formatted,theme:R?"vs-dark":"vs",maxTokenizationLineLength:w});if(m.onMouseDown(h=>{h.target.type===r.editor.MouseTargetType.CONTENT_TEXT&&m.trigger("","editor.action.revealDefinition",{})}),f&&n){const d=m.getModel().getPositionAt(L.cursorOffset);m.createDecorationsCollection([{range:new s(d.lineNumber,d.column,d.lineNumber,d.column),options:{beforeContentClassName:"my-inline-tooltip",hoverMessage:{value:`⚠️ Stack trace location ${e}:${t} ⚠️`}}}]),m.revealPositionInCenter(d);const $=m.getModel().getLineLength(d.lineNumber);m.setSelection(new a(d.lineNumber,1,d.lineNumber,$+1)),m.createDecorationsCollection([{range:new s(d.lineNumber,1,d.lineNumber,1),options:{isWholeLine:!0,className:"error-line-highlight",glyphMarginClassName:"error-gutter-icon"}}])}};console.log("loading done");const A=(e,t,n)=>`${e}#!line=${t}&col=${n}`,U=()=>{const e=`
  body {
    margin: 0;
    height: 100vh;
  }

  pre {
    height: 0 !important;
    display: none !important;
  }

  .error-line-highlight {
    background-color: rgba(255, 13, 0, 0.41);
  }

  .error-gutter-icon::before {
    content: '🦝';
    font-size: 16px;
    line-height: 1;
    display: inline-block;
    width: 100%;
    transform: scaleX(-1);
    text-align: center;
  }

  .my-inline-tooltip::after {
    content: '👉';
    display: inline-block;
    animation: point 0.8s ease-in-out infinite;
    transform-origin: center right;
  }

  @keyframes point {
    0%, 100% {
      transform: translateX(-4px);
    }
    50% {
      transform: translateX(0px);
    }
  }

  .dialog-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.3);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
  }


  .dialog {
    background: rgba(227, 227, 227, 1);
    padding: 1rem 1.5rem;
    border-radius: 8px;
    max-width: 300px;
    color: rgba(17, 0, 24, 1);
    border-top: 5px solid transparent;
    width: 100%;
    box-shadow: 0 4px 20px rgba(0,0,0,0.2);
    text-align: center;
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
  }

  .warn {
    border-top: 5px solid orange;
  }

  .error {
    border-top: 5px solid red;
  }

  .dialog-issues-url {
    text-decoration: none;
    margin-bottom: 16px;
    color: #b047caff;
  }

  .button {
    padding: 8px 25px;
    margin: 4px;
    border: 4px solid #333;
    border-radius: 12px;
    background-color: #f0f0f0;
    color: #333;
    font-size: 11px;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 1px;
    cursor: pointer;
    box-shadow: 0px 8px 0px #000;
    transition: all 0.2s ease;
    outline: none;
}

  .button:disabled {
      pointer-events: none;
      background: lightgray;
      cursor: not-allowed;
      color: #5b5b5b;
      box-shadow: 0px 4px 0px #575757;
  }

  .button:hover {
      background-color: #b047caff;
      box-shadow: 0px 4px 0px #000;
      transform: translateY(4px);
  }

  .button:active {
      background-color: #e0e0e0;
      box-shadow: 0px 0px 0px #000;
      transform: translateY(8px);
  }
`,t=document.createElement("style");t.id="🦝💅",t.type="text/css",t.innerText=e,document.head.appendChild(t)},W=e=>/(\.js$|:\d+:\d+$)/.test(e),C=()=>{const e=document.head.appendChild;document.head.appendChild=function(t){if(t instanceof HTMLLinkElement&&t.href&&t.href.includes(window.location.origin+"/assets/")){const n=chrome.runtime.getURL("/"),r=t.href.toString().split("/").pop(),s=n+"assets/"+r;t.href=s}return e.call(document.head,t)}},D=e=>{if(e instanceof Error)return e.message||e.stack||"Unknown error";if(typeof e=="string")return e;try{return JSON.stringify(e)||"Unknown error object"}catch{return"Unknown error object"}},V=e=>{const t=e.match(/^(.*):(\d+):(\d+)$/);if(!t)return{baseUrl:e};const[,n,o,r]=t;return{baseUrl:n,line:parseInt(o,10),column:parseInt(r,10)}},z=e=>{try{const n=new URL(e).hash;if(!n.startsWith("#!"))return!1;const o=new URLSearchParams(n.slice(2)),r=o.get("line"),s=o.get("col");return r!==null&&s!==null&&!isNaN(Number(r))&&!isNaN(Number(s))}catch{const t=e.indexOf("#!");if(t===-1)return!1;const n=new URLSearchParams(e.slice(t+2)),o=n.get("line"),r=n.get("col");return o!==null&&r!==null&&!isNaN(Number(o))&&!isNaN(Number(r))}};if(W(window.location.href)){const{line:e,column:t,baseUrl:n}=V(window.location.href);e&&n&&t&&(window.location.href=A(n,e,t))}try{if(z(window.location.href)){const e=window.location.hash,t=new URLSearchParams(e.slice(2)),n=Number(t.get("line")),o=Number(t.get("col")),r=`${window.location.pathname}:${n}:${o}`;history.replaceState(null,"",r),C(),U(),_(n,o)}else P(window.location.href)&&(C(),U(),_(1,1,!1))}catch(e){const t=D(e);k({type:"error",message:t,title:"Yikers, something went wrong"})}export{b as _};
