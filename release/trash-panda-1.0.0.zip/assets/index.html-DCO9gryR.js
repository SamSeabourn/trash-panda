import{T as a,D as g}from"./default-racoon-colour-C6zlquoW.js";(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))n(e);new MutationObserver(e=>{for(const t of e)if(t.type==="childList")for(const c of t.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&n(c)}).observe(document,{childList:!0,subtree:!0});function r(e){const t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?t.credentials="include":e.crossOrigin==="anonymous"?t.credentials="omit":t.credentials="same-origin",t}function n(e){if(e.ep)return;e.ep=!0;const t=r(e);fetch(e.href,t)}})();const d=()=>!!(window.matchMedia("(prefers-color-scheme: dark)").matches||window.matchMedia("(prefers-color-scheme: no-preference)").matches),i=-100,l=50,h="rgb(0,0,255)",b="rgb(0,255,0)",L="rgb(255,0,0)",y=(s,o)=>{const[r,n,e]=o.toLowerCase().replace("rgb(","").replaceAll(")","").split(",").map(m=>Number(m)),t=`rgb(${r+i},${n+i+30},${e+i-30})`,c=`rgb(${r+l+30},${n+l+0},${e+l+30})`,f=`rgb(${r},${n},${e})`,u=s.replaceAll(h,f).replaceAll(b,c).replaceAll(L,t);return console.log({svgString:s,resultString:u}),u},p=async s=>{const o=document.getElementById("app");o&&(o.innerHTML="");const r=document.createElement("div");r.className="popup-page",r.style.backgroundColor=d()?a.DARK.BACKGROUND:a.LIGHT.BACKGROUND;const e=await(await fetch(chrome.runtime.getURL("cooper-coffee.svg"))).text(),t=y(e,s),c=encodeURIComponent(t);r.innerHTML=`
    <div class='popup-container'>
      <p style='color:${d()?a.DARK.TEXT:a.LIGHT.TEXT};font-size: 1rem;text-align: center;'>
        Thanks for using Trash Panda!
        Please go to Github for features requests or issues.
      </p>
      <div style="display: flex;">
        <a href="https://github.com/SamSeabourn/trash-panda" target="_blank" >
          <button class='button'>Github</button>
        </a>
        <a href="https://buymeacoffee.com/samseabourn" target="_blank" >
          <button class='button' style="padding: 3px 35px;background-color: #FFDD00">
            <img alt="Buy me a coffee!" src="${chrome.runtime.getURL("buymeacoffeelogo.svg")}" style="height: 20px;"/>
          </button>
        </a>
      </div>  
    </div>
    <div>
      <img class="cooper" src="${`data:image/svg+xml,${c}`}">
    </div>
  `,document.body.appendChild(r)};document.addEventListener("DOMContentLoaded",()=>{chrome.tabs.query({active:!0,currentWindow:!0},s=>{const o=s[0];o&&o.id&&chrome.tabs.sendMessage(o.id,{type:"GET_COLOUR"},r=>{if(chrome.runtime.lastError){p(g);return}r&&r.color&&p(r.color)})})});
