const f={DARK:{TEXT:"#fff",BACKGROUND:"#24051eff"},LIGHT:{TEXT:"#24051eff",BACKGROUND:"#d46ec0ff"}},T="rgb(147, 132, 77)";export{T as D,f as T};
